
{
    'name': 'Stock No Negative',
    'version': '1.0',
    'category': 'Warehouse',
    'summary': 'Prevent stock moves if there is not enough stock',
    'depends': ['stock'],
    'data': [],
    'installable': True,
    'auto_install': False,
}
